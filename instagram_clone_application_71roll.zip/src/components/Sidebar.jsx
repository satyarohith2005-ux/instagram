import React from 'react';
import { NavLink } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  Home, 
  Search, 
  Compass, 
  Film, 
  MessageCircle, 
  Heart, 
  PlusSquare, 
  User,
  Menu
} from 'lucide-react';

function Sidebar({ onCreateClick }) {
  const navItems = [
    { icon: Home, label: 'Home', path: '/' },
    { icon: Search, label: 'Search', path: '/search' },
    { icon: Compass, label: 'Explore', path: '/explore' },
    { icon: Film, label: 'Reels', path: '/reels' },
    { icon: MessageCircle, label: 'Messages', path: '/messages' },
    { icon: Heart, label: 'Notifications', path: '/notifications' },
    { icon: PlusSquare, label: 'Create', path: '#', onClick: onCreateClick },
    { icon: User, label: 'Profile', path: '/profile' },
  ];

  return (
    <>
      {/* Desktop Sidebar */}
      <motion.aside 
        initial={{ x: -100, opacity: 0 }}
        animate={{ x: 0, opacity: 1 }}
        className="hidden lg:flex fixed left-0 top-0 h-screen w-64 bg-black border-r border-instagram-border flex-col z-50"
      >
        <div className="p-6">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 bg-clip-text text-transparent">
            Instagram
          </h1>
        </div>

        <nav className="flex-1 px-3">
          {navItems.map((item, index) => (
            <motion.div
              key={item.label}
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.05 }}
            >
              {item.onClick ? (
                <button
                  onClick={item.onClick}
                  className="flex items-center gap-4 px-3 py-3 rounded-lg hover:bg-instagram-gray transition-all w-full text-left group mb-1"
                >
                  <item.icon className="w-6 h-6 group-hover:scale-110 transition-transform" />
                  <span className="text-base">{item.label}</span>
                </button>
              ) : (
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `flex items-center gap-4 px-3 py-3 rounded-lg hover:bg-instagram-gray transition-all group mb-1 ${
                      isActive ? 'font-bold' : ''
                    }`
                  }
                >
                  <item.icon className="w-6 h-6 group-hover:scale-110 transition-transform" />
                  <span className="text-base">{item.label}</span>
                </NavLink>
              )}
            </motion.div>
          ))}
        </nav>

        <div className="p-3">
          <button className="flex items-center gap-4 px-3 py-3 rounded-lg hover:bg-instagram-gray transition-all w-full text-left group">
            <Menu className="w-6 h-6 group-hover:scale-110 transition-transform" />
            <span className="text-base">More</span>
          </button>
        </div>
      </motion.aside>

      {/* Mobile Bottom Navigation */}
      <motion.nav 
        initial={{ y: 100 }}
        animate={{ y: 0 }}
        className="lg:hidden fixed bottom-0 left-0 right-0 bg-black border-t border-instagram-border z-50"
      >
        <div className="flex justify-around items-center h-16">
          {[
            { icon: Home, path: '/' },
            { icon: Search, path: '/search' },
            { icon: PlusSquare, onClick: onCreateClick },
            { icon: Film, path: '/reels' },
            { icon: User, path: '/profile' },
          ].map((item, index) => (
            item.onClick ? (
              <button
                key={index}
                onClick={item.onClick}
                className="p-2 hover:scale-110 transition-transform"
              >
                <item.icon className="w-6 h-6" />
              </button>
            ) : (
              <NavLink
                key={index}
                to={item.path}
                className="p-2 hover:scale-110 transition-transform"
              >
                <item.icon className="w-6 h-6" />
              </NavLink>
            )
          ))}
        </div>
      </motion.nav>
    </>
  );
}

export default Sidebar;
