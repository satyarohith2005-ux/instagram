import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, MessageCircle, Send, Bookmark, MoreHorizontal, Smile } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

function Post({ post }) {
  const [liked, setLiked] = useState(false);
  const [saved, setSaved] = useState(false);
  const [likes, setLikes] = useState(post.likes);
  const [showComments, setShowComments] = useState(false);

  const handleLike = () => {
    setLiked(!liked);
    setLikes(liked ? likes - 1 : likes + 1);
  };

  const handleDoubleTap = () => {
    if (!liked) {
      setLiked(true);
      setLikes(likes + 1);
    }
  };

  return (
    <motion.article
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-black border-b border-instagram-border mb-4"
    >
      {/* Header */}
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500 p-[2px]">
            <img
              src={post.userAvatar}
              alt={post.username}
              className="w-full h-full rounded-full border-2 border-black object-cover"
            />
          </div>
          <div className="flex items-center gap-2">
            <span className="font-semibold text-sm">{post.username}</span>
            <span className="text-instagram-text text-sm">•</span>
            <span className="text-instagram-text text-sm">
              {formatDistanceToNow(new Date(post.timestamp), { addSuffix: true })}
            </span>
          </div>
        </div>
        <button className="hover:text-instagram-text transition-colors">
          <MoreHorizontal className="w-6 h-6" />
        </button>
      </div>

      {/* Image */}
      <motion.div 
        className="relative w-full aspect-square bg-instagram-gray cursor-pointer"
        onDoubleClick={handleDoubleTap}
      >
        <img
          src={post.image}
          alt="Post"
          className="w-full h-full object-cover"
        />
        <AnimatePresence>
          {liked && (
            <motion.div
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0, opacity: 0 }}
              className="absolute inset-0 flex items-center justify-center pointer-events-none"
            >
              <Heart className="w-24 h-24 text-white fill-white drop-shadow-lg" />
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>

      {/* Actions */}
      <div className="p-3">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-4">
            <motion.button
              whileTap={{ scale: 0.8 }}
              onClick={handleLike}
              className="hover:text-instagram-text transition-colors"
            >
              <Heart
                className={`w-6 h-6 ${liked ? 'fill-red-500 text-red-500' : ''}`}
              />
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.8 }}
              onClick={() => setShowComments(!showComments)}
              className="hover:text-instagram-text transition-colors"
            >
              <MessageCircle className="w-6 h-6" />
            </motion.button>
            <motion.button
              whileTap={{ scale: 0.8 }}
              className="hover:text-instagram-text transition-colors"
            >
              <Send className="w-6 h-6" />
            </motion.button>
          </div>
          <motion.button
            whileTap={{ scale: 0.8 }}
            onClick={() => setSaved(!saved)}
            className="hover:text-instagram-text transition-colors"
          >
            <Bookmark className={`w-6 h-6 ${saved ? 'fill-white' : ''}`} />
          </motion.button>
        </div>

        {/* Likes */}
        <div className="font-semibold text-sm mb-2">
          {likes.toLocaleString()} likes
        </div>

        {/* Caption */}
        <div className="text-sm mb-2">
          <span className="font-semibold mr-2">{post.username}</span>
          <span>{post.caption}</span>
        </div>

        {/* Comments */}
        {post.comments > 0 && (
          <button
            onClick={() => setShowComments(!showComments)}
            className="text-instagram-text text-sm mb-2 hover:text-white transition-colors"
          >
            View all {post.comments} comments
          </button>
        )}

        {/* Add Comment */}
        <div className="flex items-center gap-2 pt-2 border-t border-instagram-border">
          <Smile className="w-6 h-6 text-instagram-text cursor-pointer hover:text-white transition-colors" />
          <input
            type="text"
            placeholder="Add a comment..."
            className="flex-1 bg-transparent outline-none text-sm"
          />
          <button className="text-instagram-blue font-semibold text-sm hover:text-white transition-colors">
            Post
          </button>
        </div>
      </div>
    </motion.article>
  );
}

export default Post;
