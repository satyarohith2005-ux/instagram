import React from 'react';
import { motion } from 'framer-motion';

const suggestions = [
  {
    id: 1,
    username: 'photography_hub',
    avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150&h=150&fit=crop',
    followedBy: 'alex_photos',
  },
  {
    id: 2,
    username: 'digital_artist',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop',
    followedBy: 'travel_diaries',
  },
  {
    id: 3,
    username: 'coding_life',
    avatar: 'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?w=150&h=150&fit=crop',
    followedBy: 'tech_guru',
  },
  {
    id: 4,
    username: 'music_vibes',
    avatar: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=150&h=150&fit=crop',
    followedBy: 'foodie_life',
  },
  {
    id: 5,
    username: 'adventure_time',
    avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150&h=150&fit=crop',
    followedBy: 'nature_lover',
  },
];

function Suggestions() {
  return (
    <div className="hidden xl:block fixed right-0 top-0 w-80 h-screen p-8 overflow-y-auto">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-14 h-14 rounded-full overflow-hidden">
            <img
              src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop"
              alt="Your profile"
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <p className="font-semibold text-sm">your_username</p>
            <p className="text-instagram-text text-xs">Your Name</p>
          </div>
        </div>
        <button className="text-instagram-blue text-xs font-semibold hover:text-white transition-colors">
          Switch
        </button>
      </div>

      <div className="mb-4">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-instagram-text font-semibold text-sm">
            Suggestions For You
          </h3>
          <button className="text-white text-xs font-semibold hover:text-instagram-text transition-colors">
            See All
          </button>
        </div>

        <div className="space-y-3">
          {suggestions.map((user, index) => (
            <motion.div
              key={user.id}
              initial={{ x: 50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center justify-between"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full overflow-hidden">
                  <img
                    src={user.avatar}
                    alt={user.username}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <p className="font-semibold text-sm">{user.username}</p>
                  <p className="text-instagram-text text-xs">
                    Followed by {user.followedBy}
                  </p>
                </div>
              </div>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="text-instagram-blue text-xs font-semibold hover:text-white transition-colors"
              >
                Follow
              </motion.button>
            </motion.div>
          ))}
        </div>
      </div>

      <footer className="mt-8 text-instagram-text text-xs space-y-2">
        <div className="flex flex-wrap gap-2">
          <a href="#" className="hover:text-white transition-colors">About</a>
          <span>•</span>
          <a href="#" className="hover:text-white transition-colors">Help</a>
          <span>•</span>
          <a href="#" className="hover:text-white transition-colors">Press</a>
          <span>•</span>
          <a href="#" className="hover:text-white transition-colors">API</a>
          <span>•</span>
          <a href="#" className="hover:text-white transition-colors">Jobs</a>
          <span>•</span>
          <a href="#" className="hover:text-white transition-colors">Privacy</a>
          <span>•</span>
          <a href="#" className="hover:text-white transition-colors">Terms</a>
        </div>
        <p>© 2024 INSTAGRAM CLONE</p>
      </footer>
    </div>
  );
}

export default Suggestions;
