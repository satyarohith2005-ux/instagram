import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar';
import CreatePostModal from './CreatePostModal';

function Layout() {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-black">
      <Sidebar onCreateClick={() => setIsCreateModalOpen(true)} />
      <main className="flex-1 ml-0 lg:ml-64">
        <Outlet />
      </main>
      <CreatePostModal 
        isOpen={isCreateModalOpen} 
        onClose={() => setIsCreateModalOpen(false)} 
      />
    </div>
  );
}

export default Layout;
