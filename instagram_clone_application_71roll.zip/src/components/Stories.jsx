import React from 'react';
import { motion } from 'framer-motion';
import { Plus } from 'lucide-react';

const stories = [
  {
    id: 1,
    username: 'Your Story',
    avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop',
    isOwn: true,
  },
  {
    id: 2,
    username: 'alex_photos',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
    hasStory: true,
  },
  {
    id: 3,
    username: 'travel_diaries',
    avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=150&h=150&fit=crop',
    hasStory: true,
  },
  {
    id: 4,
    username: 'foodie_life',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop',
    hasStory: true,
  },
  {
    id: 5,
    username: 'tech_guru',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop',
    hasStory: true,
  },
  {
    id: 6,
    username: 'nature_lover',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop',
    hasStory: true,
  },
  {
    id: 7,
    username: 'fitness_pro',
    avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150&h=150&fit=crop',
    hasStory: true,
  },
];

function Stories() {
  return (
    <div className="bg-black border-b border-instagram-border py-4 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="flex gap-4 overflow-x-auto hide-scrollbar">
          {stories.map((story, index) => (
            <motion.div
              key={story.id}
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: index * 0.05 }}
              className="flex flex-col items-center gap-1 cursor-pointer group flex-shrink-0"
            >
              <div className="relative">
                <div
                  className={`w-16 h-16 rounded-full p-[2px] ${
                    story.hasStory
                      ? 'bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500'
                      : 'bg-instagram-border'
                  }`}
                >
                  <div className="w-full h-full rounded-full border-2 border-black p-[2px]">
                    <img
                      src={story.avatar}
                      alt={story.username}
                      className="w-full h-full rounded-full object-cover"
                    />
                  </div>
                </div>
                {story.isOwn && (
                  <motion.div
                    whileHover={{ scale: 1.1 }}
                    className="absolute bottom-0 right-0 w-5 h-5 bg-instagram-blue rounded-full flex items-center justify-center border-2 border-black"
                  >
                    <Plus className="w-3 h-3 text-white" />
                  </motion.div>
                )}
              </div>
              <span className="text-xs text-white truncate w-16 text-center group-hover:text-instagram-text transition-colors">
                {story.username}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Stories;
