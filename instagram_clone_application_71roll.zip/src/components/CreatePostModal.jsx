import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Image, Smile } from 'lucide-react';

function CreatePostModal({ isOpen, onClose }) {
  const [caption, setCaption] = useState('');
  const [selectedImage, setSelectedImage] = useState(null);

  const handleImageSelect = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleShare = () => {
    // Handle post creation
    onClose();
    setCaption('');
    setSelectedImage(null);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black bg-opacity-75 z-50 flex items-center justify-center p-4"
            onClick={onClose}
          >
            <motion.div
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.9, opacity: 0 }}
              className="bg-instagram-gray rounded-xl max-w-2xl w-full max-h-[90vh] overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="flex items-center justify-between p-4 border-b border-instagram-border">
                <h2 className="text-lg font-semibold">Create new post</h2>
                <button
                  onClick={onClose}
                  className="hover:text-instagram-text transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {/* Content */}
              <div className="p-6">
                {!selectedImage ? (
                  <div className="flex flex-col items-center justify-center py-12">
                    <Image className="w-24 h-24 text-instagram-text mb-4" />
                    <p className="text-xl mb-4">Select photos to share</p>
                    <label className="bg-instagram-blue text-white px-6 py-2 rounded-lg cursor-pointer hover:bg-opacity-80 transition-all">
                      Select from computer
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleImageSelect}
                        className="hidden"
                      />
                    </label>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="relative aspect-square bg-black rounded-lg overflow-hidden">
                      <img
                        src={selectedImage}
                        alt="Selected"
                        className="w-full h-full object-contain"
                      />
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full overflow-hidden">
                          <img
                            src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150&h=150&fit=crop"
                            alt="Your profile"
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <span className="font-semibold text-sm">your_username</span>
                      </div>

                      <div className="relative">
                        <textarea
                          value={caption}
                          onChange={(e) => setCaption(e.target.value)}
                          placeholder="Write a caption..."
                          className="w-full bg-transparent border border-instagram-border rounded-lg p-3 outline-none focus:border-instagram-text resize-none"
                          rows="4"
                        />
                        <button className="absolute bottom-3 right-3 text-instagram-text hover:text-white transition-colors">
                          <Smile className="w-5 h-5" />
                        </button>
                      </div>

                      <motion.button
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                        onClick={handleShare}
                        className="w-full bg-instagram-blue text-white py-2 rounded-lg font-semibold hover:bg-opacity-80 transition-all"
                      >
                        Share
                      </motion.button>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}

export default CreatePostModal;
