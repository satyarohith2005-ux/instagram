import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Grid, Bookmark, Tag, Settings } from 'lucide-react';

const posts = [
  'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1518770660439-4636190af475?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1426604966848-d7adac402bff?w=400&h=400&fit=crop',
  'https://images.unsplash.com/photo-1472214103451-9374bd1c798e?w=400&h=400&fit=crop',
];

function Profile() {
  const [activeTab, setActiveTab] = useState('posts');

  return (
    <div className="min-h-screen pb-20 lg:pb-0">
      <div className="max-w-4xl mx-auto p-4 lg:p-8">
        {/* Profile Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col lg:flex-row gap-8 mb-8"
        >
          {/* Avatar */}
          <div className="flex justify-center lg:justify-start">
            <div className="w-32 h-32 lg:w-40 lg:h-40 rounded-full bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-500 p-1">
              <div className="w-full h-full rounded-full border-4 border-black p-1">
                <img
                  src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=300&h=300&fit=crop"
                  alt="Profile"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
            </div>
          </div>

          {/* Profile Info */}
          <div className="flex-1">
            <div className="flex flex-col lg:flex-row items-center gap-4 mb-6">
              <h2 className="text-xl font-light">your_username</h2>
              <div className="flex gap-2">
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-6 py-1.5 bg-instagram-gray rounded-lg font-semibold hover:bg-instagram-border transition-colors"
                >
                  Edit profile
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  className="px-6 py-1.5 bg-instagram-gray rounded-lg font-semibold hover:bg-instagram-border transition-colors"
                >
                  View archive
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="p-1.5 bg-instagram-gray rounded-lg hover:bg-instagram-border transition-colors"
                >
                  <Settings className="w-5 h-5" />
                </motion.button>
              </div>
            </div>

            {/* Stats */}
            <div className="flex gap-8 mb-6 justify-center lg:justify-start">
              <div className="text-center lg:text-left">
                <span className="font-semibold">42</span>
                <span className="text-instagram-text ml-1">posts</span>
              </div>
              <div className="text-center lg:text-left cursor-pointer hover:text-instagram-text transition-colors">
                <span className="font-semibold">1,234</span>
                <span className="text-instagram-text ml-1">followers</span>
              </div>
              <div className="text-center lg:text-left cursor-pointer hover:text-instagram-text transition-colors">
                <span className="font-semibold">567</span>
                <span className="text-instagram-text ml-1">following</span>
              </div>
            </div>

            {/* Bio */}
            <div className="text-center lg:text-left">
              <p className="font-semibold mb-1">Your Name</p>
              <p className="text-sm">
                📸 Photography enthusiast<br />
                🌍 Travel lover<br />
                ✨ Creating memories
              </p>
            </div>
          </div>
        </motion.div>

        {/* Tabs */}
        <div className="border-t border-instagram-border">
          <div className="flex justify-center gap-12">
            <button
              onClick={() => setActiveTab('posts')}
              className={`flex items-center gap-2 py-3 border-t ${
                activeTab === 'posts'
                  ? 'border-white'
                  : 'border-transparent text-instagram-text'
              }`}
            >
              <Grid className="w-4 h-4" />
              <span className="text-xs font-semibold uppercase">Posts</span>
            </button>
            <button
              onClick={() => setActiveTab('saved')}
              className={`flex items-center gap-2 py-3 border-t ${
                activeTab === 'saved'
                  ? 'border-white'
                  : 'border-transparent text-instagram-text'
              }`}
            >
              <Bookmark className="w-4 h-4" />
              <span className="text-xs font-semibold uppercase">Saved</span>
            </button>
            <button
              onClick={() => setActiveTab('tagged')}
              className={`flex items-center gap-2 py-3 border-t ${
                activeTab === 'tagged'
                  ? 'border-white'
                  : 'border-transparent text-instagram-text'
              }`}
            >
              <Tag className="w-4 h-4" />
              <span className="text-xs font-semibold uppercase">Tagged</span>
            </button>
          </div>
        </div>

        {/* Posts Grid */}
        <div className="grid grid-cols-3 gap-1 mt-1">
          {posts.map((post, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.05 }}
              className="relative aspect-square cursor-pointer group overflow-hidden"
            >
              <img
                src={post}
                alt={`Post ${index + 1}`}
                className="w-full h-full object-cover transition-transform group-hover:scale-110"
              />
              <motion.div
                initial={{ opacity: 0 }}
                whileHover={{ opacity: 1 }}
                className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center"
              >
                <div className="flex items-center gap-6 text-white">
                  <div className="flex items-center gap-2">
                    <motion.div whileHover={{ scale: 1.2 }}>
                      ❤️
                    </motion.div>
                    <span className="font-semibold">
                      {Math.floor(Math.random() * 1000)}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <motion.div whileHover={{ scale: 1.2 }}>
                      💬
                    </motion.div>
                    <span className="font-semibold">
                      {Math.floor(Math.random() * 100)}
                    </span>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Profile;
