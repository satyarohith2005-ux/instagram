import React from 'react';
import { motion } from 'framer-motion';
import { Heart, MessageCircle } from 'lucide-react';

const exploreImages = [
  {
    id: 1,
    image: 'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=600&h=600&fit=crop',
    likes: 1234,
    comments: 45,
  },
  {
    id: 2,
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=600&fit=crop',
    likes: 2567,
    comments: 89,
  },
  {
    id: 3,
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=600&h=600&fit=crop',
    likes: 3421,
    comments: 156,
  },
  {
    id: 4,
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=600&h=600&fit=crop',
    likes: 4532,
    comments: 234,
  },
  {
    id: 5,
    image: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=600&h=600&fit=crop',
    likes: 5678,
    comments: 312,
  },
  {
    id: 6,
    image: 'https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&h=600&fit=crop',
    likes: 6789,
    comments: 423,
  },
  {
    id: 7,
    image: 'https://images.unsplash.com/photo-1470071459604-3b5ec3a7fe05?w=600&h=600&fit=crop',
    likes: 7890,
    comments: 534,
  },
  {
    id: 8,
    image: 'https://images.unsplash.com/photo-1426604966848-d7adac402bff?w=600&h=600&fit=crop',
    likes: 8901,
    comments: 645,
  },
  {
    id: 9,
    image: 'https://images.unsplash.com/photo-1472214103451-9374bd1c798e?w=600&h=600&fit=crop',
    likes: 9012,
    comments: 756,
  },
];

function Explore() {
  return (
    <div className="min-h-screen p-4 pb-20 lg:pb-4">
      <div className="grid grid-cols-3 gap-1">
        {exploreImages.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
            className="relative aspect-square group cursor-pointer overflow-hidden"
          >
            <img
              src={item.image}
              alt="Explore"
              className="w-full h-full object-cover transition-transform group-hover:scale-110"
            />
            <motion.div
              initial={{ opacity: 0 }}
              whileHover={{ opacity: 1 }}
              className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center gap-6"
            >
              <div className="flex items-center gap-2 text-white">
                <Heart className="w-6 h-6 fill-white" />
                <span className="font-semibold">{item.likes.toLocaleString()}</span>
              </div>
              <div className="flex items-center gap-2 text-white">
                <MessageCircle className="w-6 h-6 fill-white" />
                <span className="font-semibold">{item.comments}</span>
              </div>
            </motion.div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export default Explore;
