import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Edit, Phone, Video, Info, Smile, Image, Heart } from 'lucide-react';

const conversations = [
  {
    id: 1,
    username: 'alex_photos',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
    lastMessage: 'That photo is amazing!',
    timestamp: '2m',
    unread: true,
  },
  {
    id: 2,
    username: 'travel_diaries',
    avatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=150&h=150&fit=crop',
    lastMessage: 'When are we going?',
    timestamp: '1h',
    unread: false,
  },
  {
    id: 3,
    username: 'foodie_life',
    avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop',
    lastMessage: 'Recipe please! 🙏',
    timestamp: '3h',
    unread: true,
  },
];

function Messages() {
  const [selectedChat, setSelectedChat] = useState(null);
  const [message, setMessage] = useState('');

  return (
    <div className="flex h-screen pb-20 lg:pb-0">
      {/* Conversations List */}
      <div className="w-full lg:w-96 border-r border-instagram-border flex flex-col">
        {/* Header */}
        <div className="p-4 border-b border-instagram-border">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold">Messages</h2>
            <motion.button
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              className="text-instagram-text hover:text-white transition-colors"
            >
              <Edit className="w-6 h-6" />
            </motion.button>
          </div>

          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-instagram-text" />
            <input
              type="text"
              placeholder="Search"
              className="w-full bg-instagram-gray rounded-lg pl-10 pr-4 py-2 outline-none text-sm"
            />
          </div>
        </div>

        {/* Conversations */}
        <div className="flex-1 overflow-y-auto">
          {conversations.map((conv, index) => (
            <motion.div
              key={conv.id}
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
              onClick={() => setSelectedChat(conv)}
              className={`flex items-center gap-3 p-4 cursor-pointer hover:bg-instagram-gray transition-colors ${
                selectedChat?.id === conv.id ? 'bg-instagram-gray' : ''
              }`}
            >
              <div className="relative">
                <img
                  src={conv.avatar}
                  alt={conv.username}
                  className="w-14 h-14 rounded-full object-cover"
                />
                {conv.unread && (
                  <div className="absolute bottom-0 right-0 w-3 h-3 bg-instagram-blue rounded-full border-2 border-black" />
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <p className={`text-sm truncate ${conv.unread ? 'font-semibold' : ''}`}>
                    {conv.username}
                  </p>
                  <span className="text-xs text-instagram-text">{conv.timestamp}</span>
                </div>
                <p className={`text-sm truncate ${conv.unread ? 'text-white' : 'text-instagram-text'}`}>
                  {conv.lastMessage}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Chat Area */}
      <div className="hidden lg:flex flex-1 flex-col">
        {selectedChat ? (
          <>
            {/* Chat Header */}
            <div className="flex items-center justify-between p-4 border-b border-instagram-border">
              <div className="flex items-center gap-3">
                <img
                  src={selectedChat.avatar}
                  alt={selectedChat.username}
                  className="w-10 h-10 rounded-full object-cover"
                />
                <span className="font-semibold">{selectedChat.username}</span>
              </div>
              <div className="flex items-center gap-4">
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="text-instagram-text hover:text-white transition-colors"
                >
                  <Phone className="w-6 h-6" />
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="text-instagram-text hover:text-white transition-colors"
                >
                  <Video className="w-6 h-6" />
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="text-instagram-text hover:text-white transition-colors"
                >
                  <Info className="w-6 h-6" />
                </motion.button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-4">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="flex justify-end"
              >
                <div className="bg-instagram-blue text-white px-4 py-2 rounded-full max-w-xs">
                  Hey! How are you?
                </div>
              </motion.div>
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="flex"
              >
                <div className="bg-instagram-gray px-4 py-2 rounded-full max-w-xs">
                  {selectedChat.lastMessage}
                </div>
              </motion.div>
            </div>

            {/* Message Input */}
            <div className="p-4 border-t border-instagram-border">
              <div className="flex items-center gap-3">
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="text-instagram-text hover:text-white transition-colors"
                >
                  <Smile className="w-6 h-6" />
                </motion.button>
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Message..."
                  className="flex-1 bg-transparent outline-none"
                />
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="text-instagram-text hover:text-white transition-colors"
                >
                  <Image className="w-6 h-6" />
                </motion.button>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="text-instagram-text hover:text-white transition-colors"
                >
                  <Heart className="w-6 h-6" />
                </motion.button>
                {message && (
                  <motion.button
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    className="text-instagram-blue font-semibold"
                  >
                    Send
                  </motion.button>
                )}
              </div>
            </div>
          </>
        ) : (
          <div className="flex-1 flex items-center justify-center">
            <div className="text-center">
              <MessageCircle className="w-24 h-24 mx-auto mb-4 text-instagram-text" />
              <h3 className="text-xl font-semibold mb-2">Your Messages</h3>
              <p className="text-instagram-text">Send private photos and messages to a friend</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default Messages;
