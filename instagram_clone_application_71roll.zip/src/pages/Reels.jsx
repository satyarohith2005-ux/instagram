import React from 'react';
import { motion } from 'framer-motion';
import { Heart, MessageCircle, Send, Bookmark, MoreHorizontal, Volume2 } from 'lucide-react';

const reels = [
  {
    id: 1,
    username: 'alex_photos',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
    video: 'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=400&h=700&fit=crop',
    likes: 12340,
    comments: 234,
    caption: 'Amazing sunset vibes 🌅',
  },
  {
    id: 2,
    username: 'travel_diaries',
    userAvatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=150&h=150&fit=crop',
    video: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=700&fit=crop',
    likes: 23450,
    comments: 456,
    caption: 'Mountain adventures await! 🏔️',
  },
];

function Reels() {
  return (
    <div className="min-h-screen bg-black pb-20 lg:pb-0">
      <div className="max-w-md mx-auto">
        {reels.map((reel, index) => (
          <motion.div
            key={reel.id}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="relative h-screen snap-start"
          >
            {/* Video/Image */}
            <div className="absolute inset-0">
              <img
                src={reel.video}
                alt="Reel"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Gradient Overlay */}
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-black opacity-60" />

            {/* Top Bar */}
            <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
              <div className="flex items-center gap-2">
                <img
                  src={reel.userAvatar}
                  alt={reel.username}
                  className="w-8 h-8 rounded-full border-2 border-white"
                />
                <span className="font-semibold text-white text-sm">{reel.username}</span>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="px-3 py-1 bg-transparent border border-white rounded-lg text-white text-xs font-semibold"
                >
                  Follow
                </motion.button>
              </div>
              <button className="text-white">
                <MoreHorizontal className="w-6 h-6" />
              </button>
            </div>

            {/* Side Actions */}
            <div className="absolute right-4 bottom-24 flex flex-col gap-6 z-10">
              <motion.button
                whileTap={{ scale: 0.8 }}
                className="flex flex-col items-center gap-1"
              >
                <Heart className="w-7 h-7 text-white" />
                <span className="text-white text-xs font-semibold">
                  {reel.likes.toLocaleString()}
                </span>
              </motion.button>

              <motion.button
                whileTap={{ scale: 0.8 }}
                className="flex flex-col items-center gap-1"
              >
                <MessageCircle className="w-7 h-7 text-white" />
                <span className="text-white text-xs font-semibold">
                  {reel.comments}
                </span>
              </motion.button>

              <motion.button
                whileTap={{ scale: 0.8 }}
                className="flex flex-col items-center gap-1"
              >
                <Send className="w-7 h-7 text-white" />
              </motion.button>

              <motion.button
                whileTap={{ scale: 0.8 }}
                className="flex flex-col items-center gap-1"
              >
                <Bookmark className="w-7 h-7 text-white" />
              </motion.button>

              <motion.button
                whileTap={{ scale: 0.8 }}
                className="flex flex-col items-center gap-1"
              >
                <Volume2 className="w-7 h-7 text-white" />
              </motion.button>
            </div>

            {/* Bottom Caption */}
            <div className="absolute bottom-4 left-4 right-20 z-10">
              <p className="text-white text-sm">{reel.caption}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

export default Reels;
