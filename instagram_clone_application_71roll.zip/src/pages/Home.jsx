import React from 'react';
import Stories from '../components/Stories';
import Post from '../components/Post';
import Suggestions from '../components/Suggestions';

const posts = [
  {
    id: 1,
    username: 'alex_photos',
    userAvatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop',
    image: 'https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=800&h=800&fit=crop',
    likes: 1234,
    caption: 'Beautiful sunset at the beach 🌅',
    comments: 45,
    timestamp: new Date(Date.now() - 3600000),
  },
  {
    id: 2,
    username: 'travel_diaries',
    userAvatar: 'https://images.unsplash.com/photo-1527980965255-d3b416303d12?w=150&h=150&fit=crop',
    image: 'https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=800&fit=crop',
    likes: 2567,
    caption: 'Mountain adventures 🏔️ #travel #nature',
    comments: 89,
    timestamp: new Date(Date.now() - 7200000),
  },
  {
    id: 3,
    username: 'foodie_life',
    userAvatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=800&h=800&fit=crop',
    likes: 3421,
    caption: 'Homemade pizza night 🍕 Recipe in bio!',
    comments: 156,
    timestamp: new Date(Date.now() - 10800000),
  },
  {
    id: 4,
    username: 'tech_guru',
    userAvatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop',
    image: 'https://images.unsplash.com/photo-1518770660439-4636190af475?w=800&h=800&fit=crop',
    likes: 4532,
    caption: 'New setup complete! 💻 #tech #workspace',
    comments: 234,
    timestamp: new Date(Date.now() - 14400000),
  },
  {
    id: 5,
    username: 'nature_lover',
    userAvatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop',
    image: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=800&h=800&fit=crop',
    likes: 5678,
    caption: 'Into the wild 🌲 #nature #hiking',
    comments: 312,
    timestamp: new Date(Date.now() - 18000000),
  },
];

function Home() {
  return (
    <div className="min-h-screen pb-20 lg:pb-0">
      <Stories />
      
      <div className="max-w-2xl mx-auto pt-4">
        {posts.map((post) => (
          <Post key={post.id} post={post} />
        ))}
      </div>

      <Suggestions />
    </div>
  );
}

export default Home;
